const mongoose = require('mongoose');
module.exports = {
    getClassifiers: (req, res) => {
       // var ses = req.session;

        var classifiers = require('../models/classifier.js');
        var Classifier = mongoose.model('classifiers', classifiers);

       Classifier.find({}, (err, docs) => {
            if (err) {
                //console.log(docs);
                info = {
                    status: false,
                    msg: err
                }

            } else {
              
                info = {
                    status: true,
                    classifiers:docs
                }
             

            };
            res.send(info);
            res.end();
        });
    }
}