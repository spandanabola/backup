
module.exports ={
    url: 'http://localhost:1312'
}