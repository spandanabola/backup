var request = require('request');
var urls = require('./urls');
module.exports = {

    sendAttributes : (req, res) => {
        //var ses = req.session;
        console.log(req.body);
        var info={};

        request({
            url: urls.url+'/dataset/sendAttributes?userId=' + req.query.userId,
            method: 'POST',
            json: req.body
        }, function (error, response, body) {
            if(error){
                info={
                    status:false
                }
                console.log(error);
               
            }else{
                 if (response.statusCode === 200) {
                    info = {
                        status: true  
                    }
                } else {
                    info = {
                        status: false,
                        msg: body//response.statusMessage
                    }
                }
                 console.log(body);
            }
            
             res.send(info);
            res.end();
        });
      
    }
}