const mongoose = require('mongoose');
var crypto = require('crypto');
var algorithm = 'aes-256-ctr';
var password = 'd6F3Efeq';

function encrypt(text){
  var cipher = crypto.createCipher(algorithm,password)
  var crypted = cipher.update(text,'utf8','hex')
  crypted += cipher.final('hex');
  return crypted;
}

module.exports = {
    changePwd: (req, res) => {
        ses = req.session;
        if (ses.email) {

            var registerUsers = require('../models/registerUser.js');
            var RegisterUser = mongoose.model('registerusers', registerUsers);
            console.log(req.body);

            var oldPwd=encrypt(req.body.old);
            var newPwd=encrypt(req.body.new);
            RegisterUser.findOneAndUpdate({ 'email': ses.email, 'pwd': oldPwd }, { $set: { 'pwd': newPwd } }).exec(function (err, docs) {
                if (err) {
                    info = {
                        stat: false,
                        status: 404,
                        msg: "you are failed to change " + err
                    }
                    console.log(err);


                }
                else {
                    if (docs != null) {
                        info = {
                            stat: true,
                            msg: "you changed password successfully"
                        }
                    } else {
                        info = {
                            stat: false,
                            msg: "you have entered wrong old password"
                        }
                    }

                }
                res.send(info);

                res.end();
            });

        } else {
            info = {
                stat: false,
                msg: "please login to create app "
            }
            res.send(info);
            res.end();
        }
        // ses.email="spandanabola@gmail.com";

    }
}