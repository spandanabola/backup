const mongoose = require('mongoose');

module.exports = {
    checkUserExist: (req, res) => {
        var info = {};
        ses = req.session;
        var path = require("path");
        var registerUsers = require('../models/registerUser.js');
        //  var db = mongoose.connection.db;
        var RegisterUser = mongoose.model('registerUsers', registerUsers);
        console.log(req.body);
        RegisterUser.findOne({ "email": req.body.email }, (err, docs) => {
            if (err) {
                //console.log(docs);
                //console.log(hello);
                info = {
                    stat: false,
                    msg: err
                }
                // res.send(info);
                // res.end();
                // next(err);
            } else {
                if (docs != null) {
                    info = {
                        stat: true,
                        msg: "user found"
                    }
                }
                else {
                    info = {
                        stat: false,
                        msg: "user doesn't found"
                    }
                }
                //res.json({ error: err });

            };
            res.send(info);
            res.end();
        });

    }
}