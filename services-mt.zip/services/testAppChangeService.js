const mongoose = require('mongoose');
var schedule = require('./scheduler');
var scheduled = require('node-schedule');

module.exports = {
    testAppChange: (req, res) => {
        ses = req.session;
        // ses.id=parseInt(1);
        if (ses.email) {

            console.log(ses.frequency);
            var suites = [];
            var testSuites = require('../models/testSuites.js');
            var TestSuite = mongoose.model('testsuites', testSuites);
            TestSuite.find({ "appId": ses.app }, (err, docs) => {
                if (err) {
                    //console.log(docs);
                    console.log(err);
                } else {
                    // info = {
                    //     stat: false,
                    //     msg: err
                    // }
                    suites = docs;
                    console.log(suites);
                    for (var i = 0; i < suites.length; i++) {
                        updateTestSuites(suites[i]);
                    }
                    res.send(info);
                    res.end();
                };
                // res.send(info);
                // res.end();

            });
            function updateTestSuites(suites) {
                console.log("length of suites ", suites.length);
                // var pastScheduled = false;
                // var suiteName = "";
                console.log("scheduled ", suites.isScheduled);
                var pastScheduled = suites.isScheduled;
                var suiteName = suites.suiteName;
                TestSuite.findOneAndUpdate({ '_id': suites._id }, {
                    $set: {
                        'isScheduled': ses.isScheduled,
                        'frequency': ses.frequency,
                        'to': ses.to,
                        'cc': ses.cc,
                        'bcc': ses.bcc
                    }
                }).exec((err, doc) => {
                    if (err) {
                        info = {
                            stat: false,
                            msg: err
                        }
                        console.log("err");

                    } else {
                        console.log("success changing testsuites");
                        console.log(doc);
                        info = {
                            stat: true
                        }
                        if (pastScheduled == true && ses.isScheduled == false) {
                            console.log("cancelling scheduler ", suiteName);
                            scheduled.scheduledJobs[suiteName].cancel();
                        }
                        else if (pastScheduled == false && ses.isScheduled == true) {
                            console.log("started scheduler ", suiteName);
                            schedule.scheduler(doc);
                        }
                        else if (pastScheduled == true && ses.isScheduled == true) {
                            console.log("cancelling scheduler", suiteName);
                            scheduled.scheduledJobs[suiteName].cancel();
                            console.log("started scheduler ", suiteName);
                            schedule.scheduler(doc);
                        } else {

                        }
                    }
                })
            }
        }
        else {
            info = {
                stat: false,
                msg: "please login to create app "
            }
            res.send(info);
            res.end();
        }
    }
}