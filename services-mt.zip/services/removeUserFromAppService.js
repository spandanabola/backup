const mongoose=require('mongoose');
module.exports={
     removeUserFromApp: (req, res) => {
        var info = {};
        ses = req.session;
        //console.log(req.body);
        if (ses.email) {

            var path = require("path");
            var getApps = require('../models/client.js');
            var GetApp = mongoose.model('clients', getApps);

            console.log(req.body);

            GetApp.findOneAndUpdate({ "_id":  ses.app}, {
                "$pull" : { "group" :  req.body.removeEmail}
            }).exec((err, docs) => {
                if (err) {
                     info = {
                        stat: false,
                        msg: err
                    }
                    //console.log(docs);
                   
                } else {
                    //res.json({ error: err });
                    if (docs != null) {

                        info = {
                            stat: true,
                            msg: "User removed from app successfully"
                        }
                    }
                    else {
                        console.log("inside");
                        info = {
                            stat: false,
                            msg: "Something went wrong try again!!"
                        }
                    }

                };
                res.send(info);
                res.end();
            });


        } else {
            info = {
                stat: false,
                msg: "please login to create app "
            }
            res.send(info);
            res.end();
        }

    }
}