const mongoose = require("mongoose");
module.exports={
     getTestsuitesInfo: (req, res) => {
        ses = req.session;
        // ses.id=parseInt(1);
        if (ses.email) {

            var testSuites = require('../models/testSuites.js');
            var TestSuite = mongoose.model('testsuites', testSuites);
            TestSuite.find({'appId':ses.app}, (err, docs) => {
                if (err) {
                   info={
                       stat:false,
                       msg:err
                   }
                } else {
                   console.log(docs.length);
                   var count=0;
                   var testSuiteName = [];
                   for(var i=0;i<docs.length;i++){
                       if(docs[i].isScheduled==true){
                           testSuiteName.push(docs[i].suiteName);
                           count=count+1;
                       }
                   }
                   console.log(count);
                   info={
                       stat:true,
                       total:docs.length,
                       scheduled:count,
                       testSuiteName:testSuiteName
                   }
                };
                 res.send(info);
                 res.end();

            });
        }
        else {
            info = {
                stat: false,
                msg: "please login to create app "
            }
            res.send(info);
            res.end();
        }
    }
}