const mongoose=require('mongoose');
var fetch = require('node-fetch');
module.exports={
    tokenGenerate: (req, res, next) => {
        var info = {};
        var result;
        ses = req.session;
        console.log(req.body);
        // ses.email=true;
        if (ses.email) {

            var getApps = require('../models/client.js');
            var GetApp = mongoose.model('clients', getApps);


            GetApp.findOne({ "_id": ses.app }, (err, doc) => {
                if (err) {
                    //console.log(docs);
                    info = {
                        stat: false,
                        msg: err
                    }
                    res.send(info);
                    res.end();
                } else {
                    if (doc != null) {
                        var url = doc.appToken+'?grant_type=' + doc.grantType + '&client_id=' + doc.clientId + '&client_secret=' + doc.clientSecret + '&scope=' + doc.scope;
                        console.log(url);
                        fetch(url, { method: "POST" })
                            .then(function successCallback(response) {
                                
                             if (!response.ok) {
                                  throw Error(response.statusText);
                                 }
                                    return response.json();
                             

                            }).then(function(response){
                           
                                 let info = {

                                    stat: true,
                                    token: response.access_token
                                }
                                res.send(info);
                                res.end();
                            })
                            .catch(function errorCallback(err) {   
                                  next(err)
                            });
                        
                    }
                 

                };

            });

        } else {
            info = {
                stat: false,
                msg: "please login to create app "
            }
            res.send(info);
            res.end();
        }

    }
 
}