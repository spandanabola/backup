var schedule = require('./scheduler');
const mongoose = require("mongoose");
var scheduled = require('node-schedule');
var fetch = require('node-fetch');
// mongoose.Promise = require("bluebird");
// mongoose.connect("mongodb://localhost/SampleDB");
// var db = mongoose.connection.db;
module.exports = {
    
   
    
   
    
    
   
   
    
  
}