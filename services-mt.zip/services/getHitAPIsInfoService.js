const mongoose = require("mongoose");
module.exports={
     getHitAPIsInfo: (req, res) => {
        ses = req.session;
        // ses.id=parseInt(1);
        if (ses.email) {

            var testSuites = require('../models/testSuites.js');
            var TestSuite = mongoose.model('testsuites', testSuites);
            TestSuite.find({'appId':ses.app}, (err, docs) => {
                if (err) {
                   info={
                       stat:false,
                       msg:err
                   }
                } else {
                   console.log("Doc Length ",docs.length);
                   var count=0,success=0,waiting=0,failed=0;
                   for(var i=0;i<docs.length;i++){
                       for(var j=0;j<docs[i].test_suites.length;j++){
                           count=count+1;
                            console.log("Count" , count);
                           if(docs[i].test_suites[j].status=="Successfull"){
                               success=success+1;
                             }
                             else if(docs[i].test_suites[j].status=="Failed"){
                                 failed=failed+1;
                             }else if(docs[i].test_suites[j].status=="Not Checked"){
                                 waiting=waiting+1;
                             }else{

                             }
                       }
                       
                   }
                   console.log("Count" , count);
                     console.log("success" , success);
                       console.log("waiting" , waiting);
                         console.log("failed" , failed);

                   info={
                       stat:true,
                       total:count,
                       success:success,
                       failed:failed,
                       waiting:waiting
                   }
                };
                 res.send(info);
                 res.end();

            });
        }
        else {
            info = {
                stat: false,
                msg: "please login to create app "
            }
            res.send(info);
            res.end();
        }
    }
}