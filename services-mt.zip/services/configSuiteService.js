var schedule = require('./scheduler');
const mongoose = require("mongoose");
var scheduled = require('node-schedule');
module.exports = {
    configSuite: (req, res) => {
        ses = req.session;
        // ses.id=parseInt(1);
        if (ses.email) {

            console.log(req.body);

            var testSuites = require('../models/testSuites.js');
            var TestSuite = mongoose.model('testsuites', testSuites);

            var status = false;
            var frequency = "";
            console.log("scheduler");
            console.log(req.body.unScheduled);
            TestSuite.findOne({ '_id': req.body._id }, (err, docs) => {
                if (err) {
                    //console.log(docs);
                    console.log(err);
                } else {
                    // info = {
                    //     stat: false,
                    //     msg: err
                    // }
                    ses.pastScheduled = docs.isScheduled;
                    ses.pastFrequency = docs.frequency;
                    updateSuite();


                };
                // res.send(info);
                // res.end();

            });
            function updateSuite() {
                if (req.body.unScheduled == true) {
                    status = false;
                    frequency = "";

                }
                else if (req.body.frequency != undefined || req.body.frequency != "" || req.body.frequency != null) {
                    console.log("no");
                    status = true;
                    frequency = req.body.frequency;
                    console.log(req.body.frequency);
                } else {
                    console.log("yes");
                    status = false;
                    frequency = "";
                }

                TestSuite.update({ '_id': req.body._id }, { $set: { 'to': req.body.to, 'cc': req.body.cc, 'bcc': req.body.bcc, 'isScheduled': status, 'frequency': frequency, 'thresholdNotifier': req.body.thresholdNotifier } }, function (err, doc) {
                    if (err) {
                        info = {
                            stat: false,
                            msg: err

                        }
                        res.send(info);
                        res.end();

                    } else {
                        req.body.isScheduled = status;
                        req.body.frequency = frequency;
                        info = {
                            stat: true,
                            Data: req.body
                        }
                        if (ses.pastScheduled == true && req.body.isScheduled == false) {
                            console.log("cancelling scheduler", req.body.suiteName);
                            scheduled.scheduledJobs[req.body.suiteName].cancel();
                        }
                        else if (ses.pastScheduled == false && req.body.isScheduled == true) {
                            console.log("starting scheduler", req.body.suiteName);
                            schedule.scheduler(req.body);
                        }
                        else if (ses.pastScheduled == true && req.body.isScheduled == true) {
                            console.log("cancelling scheduler", req.body.suiteName);
                            scheduled.scheduledJobs[req.body.suiteName].cancel();
                            console.log("starting scheduler", req.body.suiteName);
                            schedule.scheduler(req.body);
                        } else {

                        }
                        res.send(info);
                        res.end();
                    }
                });
            }

        }
        else {
            info = {
                stat: false,
                msg: "please login to create app "
            }
            res.send(info);
            res.end();
        }
    }
}