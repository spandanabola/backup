const mongoose = require("mongoose");
module.exports={
     getUser: (req, res) => {
        ses = req.session;
        // ses.id=parseInt(1);
        if (ses.email) {

            var registerUsers = require('../models/registerUser.js');
            var RegisterUser = mongoose.model('registerusers', registerUsers);
            RegisterUser.findOne({'email':ses.email}, (err, docs) => {
                if (err) {
                   info={
                       stat:false,
                       msg:err
                   }
                } else {
                   info={
                       stat:true,
                       user:docs
                   }
                };
                 res.send(info);
                 res.end();

            });
        }
        else {
            info = {
                stat: false,
                msg: "please login to create app "
            }
            res.send(info);
            res.end();
        }
    }
}