const mongoose = require('mongoose');
const httpsProxyAgent = require('https-proxy-agent');
var fetch = require('node-fetch');
//var https = require('https');
var agents = null;
module.exports = {
    hitAuthAPI: (req, res, next) => {
        ses = req.session;
        var url = req.body.url;

        if ( url.includes("fssfed.stage.ge.com") || url.includes("amazonaws.com") || url.includes("fssfed.ge.com") || url.includes("predix.io")) {
            console.log("################################################## Inside Predix Domain ###########################################");
            agents = new httpsProxyAgent("http://10.195.49.209:80");
            //agents = new httpsProxyAgent("http://exol.proxy.ge.com:80")
            // agents = new https.Agent({
            //     rejectUnauthorized: false
            // })
        } else {
            console.log("################################################## Outside Predix Domain ###########################################");
            agents = null;
        }

        /*  if (url == "http:") {
               console.log("http ###############################################################################################################################");
               agents = new httpsProxyAgent("http://10.195.49.209:80");
           } else {
               console.log("https ###############################################################################################################################");
               agents = new httpsProxyAgent("http://10.195.49.209:80");
           }*/


        //  var header = {};


        if (JSON.stringify(req.body.header) != "{}") {
            console.log("inside JSON");
            req.body.header = JSON.parse(req.body.header);
        } else {
            req.body.header = req.body.header;
        }


        var options = {
            // These properties are part of the Fetch Standard
            method: req.body.selectedReqType,
            headers: req.body.header,
            body: req.body.body, // request body. can be null, a string, a Buffer, a Blob, or a Node.js Readable stream
            redirect: 'follow', // set to `manual` to extract redirect headers, `error` to reject redirect

            // // // The following properties are node-fetch extensions
            follow: 20,         // maximum redirect count. 0 to not follow redirect
            timeout: 0,         // req/res timeout in ms, it resets on redirect. 0 to disable (OS limit applies)
            compress: true,     // support gzip/deflate content encoding. false to disable
            size: 0,            // maximum response body size in bytes. 0 to disable
            agent: agents         // http(s).Agent instance, allows custom proxy, certificate etc.
        }
        console.log("url " + req.body.url);
        fetch(req.body.url, options)
            .then(function successCallback(response) {
                console.log("inside success hitapi");
                console.log(response.status);
                if (response.ok) {
                    info = {
                        stat: true
                    }
                    res.send(info);
                    res.end();
                } else {
                    throw Error(response.statusText);
                }
            })
            .catch(function errorCallback(err) {

                console.log("inside failure hitapi");
                console.log(err);
                info = {
                    stat: false,
                    msg: err
                }
                // res.send(info);
                // res.end();
                next(err);

            });
    }
}