package com.cg.simulator.dto;

public class SimulatorDto {
	
	private static boolean Status=false;
	private static int Time=300;
	
	public SimulatorDto(){
		super();
	}
	
	public static boolean isStatus() {
		return Status;
	}

	public static void setStatus(boolean status) {
		Status = status;
	}

	public static int getTime() {
		return Time;
	}

	public static void setTime(int time) {
		Time = time;
	}
	
	

	
}
