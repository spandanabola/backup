package com.cg.simulator.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.simulator.dto.SimulatorDto;
import com.cg.simulator.util.HandleRestCalls;
/*import com.cg.simulator.util.HandleRestCalls;*/
 
@RestController
public class SimulatorController {
	private static Timer timer;
	@Autowired
	HandleRestCalls handleRestCalls;
	/*private static final AtomicInteger count = new AtomicInteger(0);
	int jobID = count.incrementAndGet(); 
	final Timer timer= new Timer("span"+jobID);*/
	String url="https://data1-facade-solution-dev.run.azr-usw01-pr.ice.predix.io/facade/data/ingestDataWithWorkflow/1";


@RequestMapping(value = "/getStatus", method = RequestMethod.GET)
public Map<String, Object> getStatus(/*@RequestParam("data") String jsonString*/) {

	System.out.println("*********hit controller****************");
	Map<String, Object> map = new HashMap<String, Object>();
	map.put("status", SimulatorDto.isStatus());
	map.put("time", SimulatorDto.getTime());
	//System.out.println(SimulatorModel.Status);
	//System.out.println(timeSeconds);
	//System.out.println(jsonString);
	//return jsonString;
	return map;
	
}

@RequestMapping(value = "/startIngestingData", method = RequestMethod.POST, consumes={"application/json"})
public ResponseEntity<String> startIngestingData(@RequestBody Map<String, Object> inputData,@RequestParam("time") int timeSeconds) {
	
	
	SimulatorDto.setTime(timeSeconds);
	SimulatorDto.setStatus(true);
	final Object tag= inputData.get("tag");
	@SuppressWarnings("unchecked")
	final
	ArrayList<Double> values= (ArrayList<Double>) inputData.get("values");
	System.out.println(SimulatorDto.getTime());
	System.out.println(tag);
	System.out.println(values);
	
//	while(SimulatorDto.Status){
//		
//		System.out.println(new Date());
//		try {
//			Thread.sleep(SimulatorDto.Time);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
	timer = new Timer();
	/*if(SimulatorDto.getTimerStatus()=="off"){*/
		
		 TimerTask task = new TimerTask() {
		      public void run()
		       {
		    	   if(SimulatorDto.isStatus()){
		    		   System.out.println(new Date());
		    		   System.out.println(new Date().getTime());
		    		   Map<String, Object> mapper = new HashMap<String, Object>();
		    		   ArrayList<ArrayList> list1 = new ArrayList<ArrayList>();
		    		   ArrayList<Map<String, Object>> list2 = new ArrayList<Map<String, Object>>();
		    		   Map<String, Object> mapper1 = new HashMap<String, Object>();
		    		   long timestamp=new Date().getTime();
		    		   for (double value : values) {
		   					System.out.println(value);
		   					//ArrayList list = new ArrayList();
//		   					Object test[];
//		   				    test = new Object[]{timestamp, value,3};
		   				    //System.out.println(test);
		   				    
		   					ArrayList list = new ArrayList();
		   					list.add(timestamp);
		   					list.add(value);
		   					list.add(3);
		   					list1.add(list);
		   					timestamp=timestamp+100;
		   				};
		    		   mapper.put("measurement", list1);
		    		   mapper.put("tag", tag);
		    		   mapper.put("ingestor", "Spandana");
		    		   list2.add(mapper);
		    		   mapper1.put("data", list2);
		    		   System.out.println(mapper1);
		    		   
		    		   try {
						Thread.sleep(2000);
						System.out.println("2 seconds waited");
						
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						System.out.println("exception in :: thread calling::"+e.getMessage());
					}
		    		   
		    		   try {
		    				System.out.println("calling fascade-" + url);
		    				System.out.println("sending json-" + mapper1.toString());
		    				String result = handleRestCalls.handleRestCalls(url,mapper1.toString(), HttpMethod.POST);
		    			} catch (Exception e) {
		    				System.out.println("exception in :: calling fascade service::"+e.getMessage());
		 
		    			} finally {
		    			}
		    		   
		  	   }/*else{
		    		   timer.cancel();
		    		   SimulatorDto.setTimerStatus("off");
		    		}
		    	  */
		       }

          
        };
		 timer.schedule( task, 0L,SimulatorDto.getTime()*1000);
    /*}else{
    	timer.cancel();
		SimulatorDto.setTimerStatus("off");
    };
    */

    return new ResponseEntity<String>("scheduler started", HttpStatus.OK);
	
}

@RequestMapping(value = "/stopIngestingData", method = RequestMethod.GET)
public boolean stopIngestingData(@RequestParam("status") boolean status) {
	
	
	SimulatorDto.setStatus(status);
	timer.cancel();
	//SimulatorDto.setTimerStatus("on");
	System.out.println(SimulatorDto.getTime());
	System.out.println(SimulatorDto.isStatus());
	
	return true;
	
}

}