document.addEventListener('DOMContentLoaded', function() {
  var checkPageButton = document.getElementById('checkURL');
  checkPageButton.addEventListener('click', function() {

    chrome.tabs.getSelected(null, function(tab) {
      d = document;

	  d.getElementById('url').innerHTML = tab.url;
    });
  }, false);
}, false);